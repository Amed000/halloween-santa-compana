import * as i0 from "@angular/core";
import { Component, EventEmitter, Input, Output } from "@angular/core";
function MonsterCardComponent_Conditional_1_Template(rf, ctx) {
	if (rf & 1) i0.ɵɵdomElement(0, "img", 1);
	if (rf & 2) {
		const ctx_r0 = i0.ɵɵnextContext();
		i0.ɵɵdomProperty("src", ctx_r0.imagen)("alt", ctx_r0.titulo);
	}
}
var MonsterCardComponent = class MonsterCardComponent {
	constructor() {
		this.imagen = "";
		this.titulo = "Monstruo sin nombre";
		this.texto = "";
		this.textoBoton = "Ver más";
		this.botonPulsado = new EventEmitter();
	}
	pulsar() {
		this.botonPulsado.emit(this.titulo);
	}
	static {
		this.ɵfac = function MonsterCardComponent_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || MonsterCardComponent)();
		};
	}
	static {
		this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({
			type: MonsterCardComponent,
			selectors: [["lib-monster-card"]],
			inputs: {
				imagen: "imagen",
				titulo: "titulo",
				texto: "texto",
				textoBoton: "textoBoton"
			},
			outputs: { botonPulsado: "botonPulsado" },
			decls: 9,
			vars: 4,
			consts: [
				[1, "card"],
				[
					1,
					"card__img",
					3,
					"src",
					"alt"
				],
				[1, "card__body"],
				[1, "card__title"],
				[1, "card__text"],
				[
					"type",
					"button",
					1,
					"card__btn",
					3,
					"click"
				]
			],
			template: function MonsterCardComponent_Template(rf, ctx) {
				if (rf & 1) {
					i0.ɵɵdomElementStart(0, "article", 0);
					i0.ɵɵconditionalCreate(1, MonsterCardComponent_Conditional_1_Template, 1, 2, "img", 1);
					i0.ɵɵdomElementStart(2, "div", 2)(3, "h2", 3);
					i0.ɵɵtext(4);
					i0.ɵɵdomElementEnd();
					i0.ɵɵdomElementStart(5, "p", 4);
					i0.ɵɵtext(6);
					i0.ɵɵdomElementEnd();
					i0.ɵɵdomElementStart(7, "button", 5);
					i0.ɵɵdomListener("click", function MonsterCardComponent_Template_button_click_7_listener() {
						return ctx.pulsar();
					});
					i0.ɵɵtext(8);
					i0.ɵɵdomElementEnd()()();
				}
				if (rf & 2) {
					i0.ɵɵadvance();
					i0.ɵɵconditional(ctx.imagen ? 1 : -1);
					i0.ɵɵadvance(3);
					i0.ɵɵtextInterpolate(ctx.titulo);
					i0.ɵɵadvance(2);
					i0.ɵɵtextInterpolate(ctx.texto);
					i0.ɵɵadvance(2);
					i0.ɵɵtextInterpolate1(" ", ctx.textoBoton, " ");
				}
			},
			styles: ["[_nghost-%COMP%]{display:block;--%NS%mc-acento: #ff9f1c;--%NS%mc-fondo: #12081c;--%NS%mc-texto: #e6dff0}.card[_ngcontent-%COMP%]{margin:14px 0;overflow:hidden;background:var(--%NS%mc-fondo);color:var(--%NS%mc-texto);border:3px double var(--%NS%mc-acento);border-radius:18px;box-shadow:0 0 18px var(--%NS%mc-acento),0 6px 16px #0009}.card__img[_ngcontent-%COMP%]{display:block;width:100%;height:190px;object-fit:cover;border-bottom:3px double var(--%NS%mc-acento)}.card__body[_ngcontent-%COMP%]{padding:14px 16px 18px}.card__title[_ngcontent-%COMP%]{margin:0 0 8px;color:var(--%NS%mc-acento);font-family:Creepster,Georgia,serif;font-size:1.8rem;letter-spacing:1px;text-shadow:2px 2px 0 #000}.card__text[_ngcontent-%COMP%]{margin:0;line-height:1.5}.card__btn[_ngcontent-%COMP%]{margin-top:14px;padding:10px 22px;border:2px solid var(--%NS%mc-acento);border-radius:999px;background:transparent;color:var(--%NS%mc-acento);font-weight:700;cursor:pointer;transition:all .2s}.card__btn[_ngcontent-%COMP%]:hover{background:var(--%NS%mc-acento);color:#000}.card__btn[_ngcontent-%COMP%]:active{transform:scale(.94);box-shadow:0 0 14px var(--%NS%mc-acento)}"]
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MonsterCardComponent, [{
		type: Component,
		args: [{
			selector: "lib-monster-card",
			imports: [],
			template: "<article class=\"card\">\n  @if (imagen) {\n    <img class=\"card__img\" [src]=\"imagen\" [alt]=\"titulo\" />\n  }\n  <div class=\"card__body\">\n    <h2 class=\"card__title\">{{ titulo }}</h2>\n    <p class=\"card__text\">{{ texto }}</p>\n    <button class=\"card__btn\" type=\"button\" (click)=\"pulsar()\">\n      {{ textoBoton }}\n    </button>\n  </div>\n</article>",
			styles: [":host{display:block;--mc-acento: #ff9f1c;--mc-fondo: #12081c;--mc-texto: #e6dff0}.card{margin:14px 0;overflow:hidden;background:var(--mc-fondo);color:var(--mc-texto);border:3px double var(--mc-acento);border-radius:18px;box-shadow:0 0 18px var(--mc-acento),0 6px 16px #0009}.card__img{display:block;width:100%;height:190px;object-fit:cover;border-bottom:3px double var(--mc-acento)}.card__body{padding:14px 16px 18px}.card__title{margin:0 0 8px;color:var(--mc-acento);font-family:Creepster,Georgia,serif;font-size:1.8rem;letter-spacing:1px;text-shadow:2px 2px 0 #000}.card__text{margin:0;line-height:1.5}.card__btn{margin-top:14px;padding:10px 22px;border:2px solid var(--mc-acento);border-radius:999px;background:transparent;color:var(--mc-acento);font-weight:700;cursor:pointer;transition:all .2s}.card__btn:hover{background:var(--mc-acento);color:#000}.card__btn:active{transform:scale(.94);box-shadow:0 0 14px var(--mc-acento)}\n"]
		}]
	}], null, {
		imagen: [{ type: Input }],
		titulo: [{ type: Input }],
		texto: [{ type: Input }],
		textoBoton: [{ type: Input }],
		botonPulsado: [{ type: Output }]
	});
})();
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MonsterCardComponent, {
		className: "MonsterCardComponent",
		filePath: "lib/monster-card/monster-card.ts",
		lineNumber: 9
	});
})();
export { MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map